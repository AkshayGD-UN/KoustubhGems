package com.example.koustubhgems;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    TextView mGotohomeBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mGotohomeBtn = findViewById(R.id.login_activity_gotohome_btn);





        mGotohomeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // This method will be executed when clicked on go to home btn
                Intent i = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(i);
                finish();

            }
        });

    }



}
